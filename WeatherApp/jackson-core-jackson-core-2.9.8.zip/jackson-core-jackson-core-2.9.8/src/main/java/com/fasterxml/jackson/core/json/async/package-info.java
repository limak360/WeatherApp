/**
 * Non-blocking ("async") JSON parser implementation.
 *
 * @since 2.9
 */
package com.fasterxml.jackson.core.json.async;
